License: GPL

Source code at:
http://axem.boo.pl/maxem/bombattack/bombattack-leveleditor-src.tar.bz2
http://axem.boo.pl/maxem/bombattack/bombattack-src.tar.bz2